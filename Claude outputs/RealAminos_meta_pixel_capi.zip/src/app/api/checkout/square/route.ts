import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import type { SupabaseClient } from "@supabase/supabase-js";
import { guestCheckoutError } from "@/lib/checkout/guest";
import type { NewOrderPayload, PointTransaction } from "@/types/database";
import { calculateShippingFee } from "@/lib/shipping/rate";
import { checkLocalDelivery } from "@/lib/shipping/localDelivery";
import { resolveVariant } from "@/lib/inventory/resolveVariant";
import { resolveDiscount } from "@/lib/checkout/resolveDiscount";
import { readAdClickId } from "@/lib/ads/adClickId";
import { readMetaTracking } from "@/lib/meta/capi";
import { bulkUnitPrice } from "@/lib/promotions/bulkPricing";
import { buildFreeBacItem, extractFreeBacRequest } from "@/lib/promotions/freeBacWater";
import { createSquarePaymentLink, isSquareConfigured } from "@/lib/square/client";

const SITE_URL = "https://shoprealaminos.com";

// POST /api/checkout/square — same validation as /api/checkout/zelle and
// /api/checkout/bitcoin (stock check, reward-reservation re-verification,
// server-side bulk pricing, discount code and shipping recomputation; nothing
// is trusted from the client), but paid by card on a Square-hosted payment
// page. No card discount — it's just another way to pay at the regular price.
//
// Creates a REAL `orders` row immediately (status "Awaiting Payment", payment
// method "square"), then a Square payment link for the exact amount due.
// Stock, the status flip to Processing and the confirmation email all wait for
// Square to confirm the payment — see /api/webhooks/square,
// lib/square/syncPayment.ts and finalizeOrderPayment().
export async function POST(request: Request) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  // No login required: a signed-in customer's order is tied to their account
  // (points, order history); anyone else checks out as a guest, identified by
  // the email they enter. Guest rules are applied below once the cart is read.

  if (!isSquareConfigured()) {
    return NextResponse.json(
      { error: "Card payments aren't available right now — please choose Zelle or Bitcoin." },
      { status: 503 }
    );
  }

  const body = (await request.json()) as NewOrderPayload;
  // Free "every $100" BAC Water: pulled out of the cart lines up front so the
  // rest of this route only sees real paid / points lines. How many are
  // actually granted is decided below, once the order total is known.
  const requestedFreeBac = extractFreeBacRequest(body);
  if (!body.items?.length) {
    return NextResponse.json({ error: "Order must include at least one item." }, { status: 400 });
  }

  const hasPaidItem = body.items.some((i) => !i.pointTransactionId);
  if (!hasPaidItem) {
    return NextResponse.json(
      { error: "Add at least one item you're paying for to check out — a cart can't be only free, points-redeemed rewards." },
      { status: 400 }
    );
  }

  const shipping = body.shipping;
  const required: (keyof typeof shipping)[] = ["name", "phone", "email", "addressLine1", "city", "state", "zip"];
  const missing = shipping ? required.filter((field) => !shipping[field]?.toString().trim()) : required;
  if (missing.length > 0) {
    return NextResponse.json(
      { error: `Missing required shipping info: ${missing.join(", ")}` },
      { status: 400 }
    );
  }

  const admin = createAdminClient();

  // Guest checkout: no points (they belong to an account), a valid email, and
  // a light limit on unpaid orders per email.
  if (!user) {
    if (body.items.some((i) => i.pointTransactionId)) {
      return NextResponse.json(
        { error: "Points rewards need an account — log in, or remove the reward from your cart to check out as a guest." },
        { status: 400 }
      );
    }
    const guestError = await guestCheckoutError(admin, shipping.email);
    if (guestError) return NextResponse.json({ error: guestError }, { status: 400 });
  }
  // Signed-in customers insert under their own session (Row Level Security
  // enforces user_id); guests have no session, so the server inserts for them.
  const writer: SupabaseClient = user ? supabase : admin;

  // Point-in-time stock check (not a hold/reservation — stock only moves once
  // payment settles). Also resolve+cache each line's real product_id here so
  // the order_items insert below doesn't have to re-query for it.
  const resolvedProductIdByLine = new Map<string, string>();
  // Real, current unit price per line, read straight from the database —
  // never trusted from whatever price the client happened to send. This is
  // just the variant's real stored price (see
  // 0025_restore_original_prices.sql — any "was" price is display-only via
  // compare_at_price and never affects what's actually charged), so what's
  // charged always matches what the product page showed.
  const realUnitPriceByLine = new Map<string, number>();
  for (const item of body.items) {
    const variant = await resolveVariant(admin, item);
    if (!variant) {
      return NextResponse.json(
        { error: `${item.productName} (${item.size}) is no longer available.` },
        { status: 400 }
      );
    }
    if (variant.stock < item.qty) {
      return NextResponse.json(
        {
          error:
            variant.stock === 0
              ? `${item.productName} (${item.size}) is currently out of stock.`
              : `Only ${variant.stock} left of ${item.productName} (${item.size}) — lower the quantity in your cart.`,
        },
        { status: 400 }
      );
    }
    const lineKey = item.pointTransactionId ?? `${item.productId}::${item.size}`;
    resolvedProductIdByLine.set(lineKey, variant.product_id);
    realUnitPriceByLine.set(lineKey, variant.price);
  }

  const rewardTxIds = [...new Set(body.items.map((i) => i.pointTransactionId).filter(Boolean))] as string[];
  const reservationById = new Map<string, PointTransaction>();

  if (rewardTxIds.length > 0) {
    const { data: reservations, error: resError } = await admin
      .from("point_transactions")
      .select("*")
      .in("id", rewardTxIds)
      .returns<PointTransaction[]>();

    if (resError) {
      return NextResponse.json({ error: resError.message }, { status: 500 });
    }

    for (const id of rewardTxIds) {
      const found = reservations?.find((r) => r.id === id);
      if (!found || found.user_id !== user?.id || found.type !== "redeemed" || found.order_id || found.voided) {
        return NextResponse.json(
          { error: "One of your redeemed rewards is no longer valid — remove it from your cart and try again." },
          { status: 400 }
        );
      }
      reservationById.set(id, found);
    }
  }

  const normalizedItems = body.items.map((i) => {
    if (i.pointTransactionId) return { ...i, unitPrice: 0 };
    const lineKey = i.pointTransactionId ?? `${i.productId}::${i.size}`;
    // The variant's real database price, then the quantity (bulk) discount
    // for this line's qty — recomputed here from scratch so the charged
    // price never depends on anything the browser sent. Same function the
    // cart uses to show the customer their price (lib/promotions/bulkPricing.ts).
    const basePrice = realUnitPriceByLine.get(lineKey) ?? i.unitPrice;
    return { ...i, unitPrice: bulkUnitPrice(basePrice, i.qty) };
  });

  const subtotal = normalizedItems.reduce((sum, i) => sum + i.unitPrice * i.qty, 0);
  const pointsRedeemedTotal = [...reservationById.values()].reduce((sum, r) => sum + Math.abs(r.points), 0);
  // Free local delivery (Arizona, within 50 miles of Surprise, AZ). Asked for
  // by the browser but verified here — an address that doesn't qualify is
  // rejected, never silently given free delivery.
  const deliveryMethod: "ship" | "local" = body.deliveryMethod === "local" ? "local" : "ship";
  if (deliveryMethod === "local") {
    const local = await checkLocalDelivery({
      addressLine1: shipping.addressLine1,
      city: shipping.city,
      state: shipping.state,
      zip: shipping.zip,
    });
    if (!local.eligible) {
      return NextResponse.json({ error: local.message }, { status: 400 });
    }
  }
  const shippingFee = deliveryMethod === "local" ? 0 : calculateShippingFee(subtotal, shipping.state);

  // A customer-typed discount code, if any, applies on top of the subtotal
  // above — which already reflects the site-wide sale, if one's running,
  // via the real per-line prices computed above. See resolveDiscount.ts;
  // the Zelle route uses the same function, so both payment paths land on
  // the same total for the same cart (before Zelle's own 5%).
  let discountCode: string | null;
  let discountPercent: number;
  try {
    const resolved = await resolveDiscount(admin, body.discountCode, {
      userEmail: user?.email,
      shippingEmail: shipping.email,
      shippingPhone: shipping.phone,
    });
    discountCode = resolved.code;
    discountPercent = resolved.percent;
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "That discount code is no longer valid." },
      { status: 400 }
    );
  }

  const total = Math.round(subtotal * (1 - discountPercent / 100) * 100) / 100;

  // One free BAC Water per full $100 of product total (after discounts, before
  // shipping) — decided here, never from what the browser sent.
  const freeBacItem = await buildFreeBacItem(admin, {
    requestedQty: requestedFreeBac,
    qualifyingTotal: total,
    paidLines: body.items.map((i) => ({
      productId: resolvedProductIdByLine.get(i.pointTransactionId ?? `${i.productId}::${i.size}`) ?? "",
      size: i.size,
      qty: i.qty,
    })),
  });
  // No card discount: what's due is exactly total + shipping.
  const amountDue = Math.round((total + shippingFee) * 100) / 100;

  // Insert under the customer's own session — orders_insert_own (see
  // 0001_init.sql) is what actually enforces user_id can't be spoofed.
  const { data: order, error: orderError } = await writer
    .from("orders")
    .insert({
      user_id: user?.id ?? null,
      subtotal,
      discount_code: discountCode,
      discount_percent: discountPercent,
      total,
      points_redeemed: pointsRedeemedTotal,
      shipping_fee: shippingFee,
      // Only sent for local orders, so normal checkouts keep working even
      // before 0033_local_delivery.sql has been run.
      ...(deliveryMethod === "local" ? { delivery_method: "local" } : {}),
      payment_method: "square",
      zelle_discount_amount: 0,
      status: "Awaiting Payment",
      shipping_name: shipping.name,
      shipping_phone: shipping.phone,
      shipping_email: shipping.email,
      shipping_address_line1: shipping.addressLine1,
      shipping_address_line2: shipping.addressLine2 || null,
      shipping_city: shipping.city,
      shipping_state: shipping.state,
      shipping_zip: shipping.zip,
    })
    .select()
    .single();

  if (orderError || !order) {
    return NextResponse.json({ error: orderError?.message ?? "Could not create order." }, { status: 500 });
  }

  // Remember which Google Ads click (if any) brought this customer, so the
  // admin can tell ad orders apart and upload any Google didn't credit. A
  // separate best-effort update on purpose: it must never stop a checkout, and
  // it just does nothing until 0034_order_ad_click_id.sql has been run.
  const adClickId = readAdClickId();
  if (adClickId) {
    await admin.from("orders").update({ ad_click_id: adClickId }).eq("id", order.id);
  }

  // Same idea for Meta (Facebook / Instagram) ads: keep the buyer's Meta
  // browser IDs, IP and browser string so the server-side Purchase event
  // (lib/meta/capi.ts) can be matched to the ad click. Best-effort and silent
  // until 0040_meta_tracking.sql has been run — it never blocks a checkout.
  await admin.from("orders").update({ meta_tracking: readMetaTracking() }).eq("id", order.id);

  const { error: itemsError } = await writer.from("order_items").insert([
    ...normalizedItems.map((i) => ({
      order_id: order.id,
      product_name: i.productName,
      size: i.size,
      qty: i.qty,
      unit_price: i.unitPrice,
      product_id: resolvedProductIdByLine.get(i.pointTransactionId ?? `${i.productId}::${i.size}`) ?? null,
    })),
    ...(freeBacItem
      ? [
          {
            order_id: order.id,
            product_name: freeBacItem.productName,
            size: freeBacItem.size,
            qty: freeBacItem.qty,
            unit_price: 0,
            product_id: freeBacItem.productId,
          },
        ]
      : []),
  ]);

  if (itemsError) {
    // Best-effort cleanup so a failed item insert doesn't leave an empty
    // "ghost" order sitting in Awaiting Payment forever.
    await admin.from("orders").delete().eq("id", order.id);
    return NextResponse.json({ error: itemsError.message }, { status: 500 });
  }

  // Create the Square payment link for exactly what's due. If this fails, remove the
  // just-created order (items cascade) so no ghost "Awaiting Payment" order is
  // left behind — reservations aren't linked yet, so reward points are untouched.
  let link;
  try {
    link = await createSquarePaymentLink({
      amountUsd: amountDue,
      orderId: order.id,
      orderNumber: order.order_number,
      itemSummary: [
        ...normalizedItems.map((i) => `${i.productName} (${i.size}) x${i.qty}`),
        ...(freeBacItem ? [`${freeBacItem.productName} (${freeBacItem.size}) x${freeBacItem.qty}`] : []),
      ].join("; "),
      buyerEmail: shipping.email,
      redirectUrl: `${SITE_URL}/thank-you?order=${order.id}`,
    });
  } catch (err) {
    console.error("checkout/square: Square payment link creation failed", err);
    await admin.from("orders").delete().eq("id", order.id);
    // Staff (is_admin) get Square's actual error text so a setup problem —
    // wrong token, wrong location, sandbox/production mix-up — can be seen
    // right in the cart. Everyone else just gets the friendly message.
    const { data: staff } = user
      ? await supabase.from("profiles").select("is_admin").eq("id", user.id).single()
      : { data: null };
    const detail = staff?.is_admin && err instanceof Error ? ` [Admin detail: ${err.message}]` : "";
    return NextResponse.json(
      { error: `Couldn't start the card payment — please try again, or choose Zelle or Bitcoin.${detail}` },
      { status: 502 }
    );
  }

  // Written with the service-role client: customers have no UPDATE policy on
  // orders (only admins do), and these columns should never be client-writable.
  const { error: linkError } = await admin
    .from("orders")
    .update({ square_order_id: link.orderId, square_payment_link_id: link.id, square_checkout_url: link.url })
    .eq("id", order.id);

  if (linkError) {
    console.error("checkout/square: could not save Square ids on order", order.id, linkError.message);
    await admin.from("orders").delete().eq("id", order.id);
    return NextResponse.json({ error: "Couldn't start the card payment — please try again." }, { status: 500 });
  }

  // Link reward reservations to the real order now that it exists for real
  // (same known tradeoff as Zelle — see that route; an abandoned unpaid card
  // order stays "Awaiting Payment" until staff clear it from /admin/orders).
  if (rewardTxIds.length > 0) {
    await admin.from("point_transactions").update({ order_id: order.id }).in("id", rewardTxIds);
  }

  // The owner's "New Order" email is sent later — when the customer reaches
  // /thank-you or the payment auto-confirms (see notifyAdminNewOrder).

  return NextResponse.json(
    {
      orderId: order.id,
      orderNumber: order.order_number,
      createdAt: order.created_at,
      amountDue,
      checkoutUrl: link.url,
    },
    { status: 201 }
  );
}
