import Link from "next/link";
import type { Metadata } from "next";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { syncSquareOrderPayment } from "@/lib/square/syncPayment";
import { notifyAdminNewOrder } from "@/lib/orders/notifyAdminNewOrder";
import type { OrderWithItems } from "@/types/database";
import ThankYouTracker from "./ThankYouTracker";

// Order-specific and private — keep it out of search results (robots.ts
// disallows it too).
export const metadata: Metadata = {
  title: "Thank you for your order",
  robots: { index: false, follow: false },
};

// Always read the live order — never cache this page.
export const dynamic = "force-dynamic";

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function money(n: number) {
  return `$${n.toFixed(2)}`;
}

// The page every paid order ends up on:
//   - Zelle:   ZellePaymentStatus sends the customer here right after they
//              tap "I've Sent My Zelle Payment" and it succeeds.
//   - Bitcoin: BTCPay's "Return to store" button points here (the invoice's
//              redirectURL — see /api/checkout/bitcoin).
//   - Card:    Square sends the customer back here after they pay (the payment
//              link's redirect_url — see /api/checkout/square).
// URL: https://shoprealaminos.com/thank-you?order=<order id>
//
// A signed-in customer's order is read with their own session, so Row Level
// Security means only the person who placed it can see it. A guest order (no
// account) is found by its order id — an unguessable UUID that's only ever sent
// to the person who placed it (payment redirect, their own browser). The Google Ads
// conversion (ThankYouTracker) only fires once the order is out of
// "Awaiting Payment".
export default async function ThankYouPage({
  searchParams,
}: {
  searchParams: { order?: string };
}) {
  const orderId = searchParams.order ?? "";

  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  let current: OrderWithItems | null = null;
  if (UUID.test(orderId)) {
    if (user) {
      const { data } = await supabase
        .from("orders")
        .select("*, order_items(*)")
        .eq("id", orderId)
        .maybeSingle<OrderWithItems>();
      current = data;
    }
    // Not one of their own account orders (or not signed in): look for a guest
    // order with this id. Orders that belong to an account are never returned
    // this way.
    if (!current) {
      const { data } = await createAdminClient()
        .from("orders")
        .select("*, order_items(*)")
        .eq("id", orderId)
        .is("user_id", null)
        .maybeSingle<OrderWithItems>();
      current = data;
    }
  }

  // A card customer lands here seconds after paying — often before Square's
  // webhook has arrived. Ask Square directly (server-side, with our own API
  // token) whether it's paid and finalize right now if so, so the page shows
  // the real thank-you immediately. Safe to repeat: the finalize step claims
  // the order atomically, so this and the webhook can never both apply.
  if (current && current.status === "Awaiting Payment" && current.payment_method === "square") {
    const synced = await syncSquareOrderPayment(createAdminClient(), current);
    if (synced.state === "paid") current = { ...current, status: "Processing" };
  }
  const order = current;
  const isGuest = !!order && !order.user_id;

  if (!order) {
    return (
      <main className="site-main">
        <div className="wrap" style={{ maxWidth: 640, textAlign: "center", paddingTop: 48 }}>
          <h1>We couldn&apos;t find that order</h1>
          <p style={{ color: "var(--muted)" }}>
            It may belong to a different account. If you&apos;re signed in, you can see every order
            on your account on the My Orders page.
          </p>
          <Link className="btn" href="/account/orders" style={{ display: "inline-block", marginTop: 12 }}>
            Go to My Orders
          </Link>
        </div>
      </main>
    );
  }

  const paid = order.status !== "Awaiting Payment";

  // Reaching this page with a paid/confirmed order is what triggers the
  // owner's "New Order" email (once per order — see notifyAdminNewOrder).
  // Still-pending card/Bitcoin orders send it later, when they confirm.
  if (paid) await notifyAdminNewOrder(createAdminClient(), order);
  // What the customer actually paid: product total (after any code) plus
  // shipping, minus the Zelle discount if any. Same math as the checkout
  // routes' amountDue. A null total is a pre-discount-codes order = subtotal.
  const amountPaid =
    Math.round(((order.total ?? order.subtotal) + order.shipping_fee - order.zelle_discount_amount) * 100) / 100;
  const itemCount = order.order_items.reduce((s, i) => s + i.qty, 0);

  return (
    <main className="site-main">
      <ThankYouTracker
        orderNumber={order.order_number}
        value={amountPaid}
        paid={paid}
        contentIds={Array.from(new Set(order.order_items.map((i) => i.product_id).filter((x): x is string => !!x)))}
        numItems={itemCount}
        buyer={{
          email: order.shipping_email ?? user?.email,
          phone: order.shipping_phone,
          name: order.shipping_name,
          street: order.shipping_address_line1,
          city: order.shipping_city,
          state: order.shipping_state,
          zip: order.shipping_zip,
        }}
      />

      <div className="wrap" style={{ maxWidth: 680, paddingTop: 40 }}>
        <div className="card" style={{ textAlign: "center", padding: "36px 28px" }}>
          {paid ? (
            <>
              <div style={{ fontSize: 44, color: "var(--ok)", lineHeight: 1 }}>✓</div>
              <h1 style={{ margin: "12px 0 8px" }}>Thank you for your order!</h1>
              <p style={{ color: "var(--muted)", margin: "0 0 4px" }}>
                Order <strong style={{ color: "var(--ink)" }}>{order.order_number}</strong> is now
                processing.
              </p>
              <p style={{ color: "var(--muted)", margin: 0 }}>
                A confirmation email is on its way to{" "}
                <strong style={{ color: "var(--ink)" }}>{order.shipping_email ?? user?.email}</strong>.
                {order.delivery_method === "local"
                  ? "This is a free local delivery order — we'll deliver it same or next day and email you when it's on the way."
                  : "We'll email your tracking number as soon as it ships."}
              </p>
            </>
          ) : (
            <>
              <div style={{ fontSize: 40, lineHeight: 1 }}>⏳</div>
              <h1 style={{ margin: "12px 0 8px" }}>Waiting for your payment to confirm</h1>
              <p style={{ color: "var(--muted)", margin: "0 0 4px" }}>
                Order <strong style={{ color: "var(--ink)" }}>{order.order_number}</strong> is
                saved but we haven&apos;t seen the payment confirm yet.
              </p>
              <p style={{ color: "var(--muted)", margin: 0 }}>
                {order.payment_method === "bitcoin"
                  ? isGuest
                    ? "Bitcoin payments usually confirm within about an hour. This page updates by itself, and we'll email you when it confirms."
                    : "Bitcoin payments usually confirm within about an hour. This page updates by itself — you can leave it open or check My Orders later."
                  : order.payment_method === "square"
                  ? isGuest
                    ? "Card payments usually confirm within seconds. This page updates by itself — if you haven't paid yet, go back to your cart and check out again."
                    : "Card payments usually confirm within seconds. This page updates by itself — if you haven't paid yet, finish from the My Orders page."
                  : isGuest
                  ? "If you already sent it, this page will update shortly. Otherwise place the order again from your cart."
                  : "If you already sent it, this page will update shortly. Otherwise finish paying from the My Orders page."}
              </p>
            </>
          )}

          <div
            style={{
              margin: "24px 0 0",
              paddingTop: 18,
              borderTop: "1px solid var(--line)",
              textAlign: "left",
              fontSize: 14,
            }}
          >
            {order.order_items.map((item) => (
              <div
                key={item.id}
                style={{ display: "flex", justifyContent: "space-between", gap: 12, padding: "4px 0" }}
              >
                <span>
                  {item.product_name} ({item.size}) × {item.qty}
                </span>
                <span>{money(item.unit_price * item.qty)}</span>
              </div>
            ))}
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                fontWeight: 800,
                paddingTop: 10,
                marginTop: 6,
                borderTop: "1px solid var(--line)",
              }}
            >
              <span>
                {paid ? "Total paid" : "Total due"} · {itemCount} item{itemCount === 1 ? "" : "s"}
              </span>
              <span>{money(amountPaid)}</span>
            </div>
          </div>

          <div style={{ display: "flex", gap: 10, justifyContent: "center", flexWrap: "wrap", marginTop: 24 }}>
            {isGuest ? (
              <Link className="btn" href="/shop/all">
                Keep shopping
              </Link>
            ) : (
              <>
                <Link className="btn" href="/account/orders">
                  Track my order
                </Link>
                <Link className="btn btn-outline" href="/shop/all">
                  Keep shopping
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}
